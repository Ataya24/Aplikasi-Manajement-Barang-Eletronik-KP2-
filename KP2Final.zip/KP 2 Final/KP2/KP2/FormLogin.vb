﻿Public Class FormLogin
    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        If txt_password.Text = "0123456789" Then
            Me.Hide()
            Dim dashboardForm As New Dashboard()
            MessageBox.Show("Login berhasil!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dashboardForm.ShowDialog()
        Else
            MessageBox.Show("Password salah!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txt_password.Clear()
        End If
    End Sub

    Private Sub btn_reset_Click(sender As Object, e As EventArgs) Handles btn_reset.Click
        txt_password.Clear()
    End Sub

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub
End Class
